<?php

    $busca = $_POST['buscaInicial'];

    if($busca == "feijao") {
        echo "top";
    }