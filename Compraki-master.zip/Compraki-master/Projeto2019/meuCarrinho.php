<html>
<head>
    <title>CompreAki</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">CompreAki</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#sobre" class="hoversero">SOBRE NÓS</a></li>
                <li><a href="#menu1" class="hoversero">MENU</a></li>
                <li><a href="meuCarrinho.php">CARRINHO</a></li>
                <li><a href="#pricing1" class="hoversero"><div onclick="document.getElementById('id01').style.display='block'" style="width:auto;">LOGOUT</div></a></li>

            </ul>
        </div>
    </div>
</nav>
<br><br><br>
<h1 style="text-align: center">Seu Carrinho</h1>
<div style="margin-left:20%; margin-right: 20%">
<ul class="list-group">
    <li class="list-group-item d-flex justify-content-between align-items-center">
        Sabonete Dove - R$<?= 8* 2.15; ?>
        <span class="badge badge-danger"><a href="#" style="color:white">X</a></span>
        <span class="badge badge-primary badge-light">8 un</span>
    </li>
    <li class="list-group-item d-flex justify-content-between align-items-center">
        Arroz Vila Nova 5Kg- R$10,45
        <span class="badge badge-danger"><a href="#" style="color:white">X</a></span>
        <span class="badge badge-primary badge-pill">1 un</span>
    </li>
    <li class="list-group-item d-flex justify-content-between align-items-center">
        Café Damasco Extra Forte 500g - <?= 3* 7.65 ?>
        <span class="badge badge-danger"><a href="#" style="color:white">X</a></span>
        <span class="badge badge-primary badge-pill">3 un</span>
    </li>
</ul>
    <a href="pagamento.php"><button class="btn btn-primary">Confirmar Compra</button></a>
</div>
</body></html>