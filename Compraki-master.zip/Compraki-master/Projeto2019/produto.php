
<!DOCTYPE html>
<html lang="en">
<title>CompreAki</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<link rel="stylesheet" type="text/css" href="estilo.css">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}

.card-img-top img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer; width: 10%; height: 10%}
.card-img-top img:hover{opacity:1}
</style>
<body>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-red w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Close Menu</a>
  <div class="w3-container">
    <h3 class="w3-padding-64"><b>CompreAki</b></h3>
  </div>
  <div class="w3-bar-block">
  <a href="index.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">HOME</a>
    <a href="#showcase" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Cremes</a> 
    <a href="#services" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Shampoo</a> 
    <a href="#designers" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Sabonetes</a> 
    <a href="#packages" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Escova dental</a> 
    <a href="#contact" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Pasta de dente</a>
  </div>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">
  <a href="javascript:void(0)" class="w3-button w3-red w3-margin-right" onclick="w3_open()">☰</a>
  <span>Company Name</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:340px;margin-right:40px">

  <!-- Header -->
  <div class="w3-container" style="margin-top:80px" id="showcase">
    <h1 class="w3-jumbo"><b>Produtos Higiênicos</b></h1>
    <h1 class="w3-xxxlarge w3-text-red"><b>Cremes</b></h1>
    <hr style="width:50px;border:5px solid red" class="w3-round">
  </div>

<div class="list-group-item-danger">
    <div class="card" style="width: 18rem; padding-left: 5%">
        <img class="card-img-top" src="img/creme1.jpg" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Creme Nivea</h5>
            <h6 class="card-text">R$11,75</h6>
            <button class="btn btn-primary">Adicionar ao Carrinho</button>
            <hr>
        </div>
    </div>
    <div class="card" style="width: 18rem;padding-left: 5%">
        <img class="card-img-top" src="img/creme2.jpg" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Creme Protetor Solar</h5>
            <h6 class="card-text">R$11,75</h6>
            <button class="btn btn-primary">Adicionar ao Carrinho</button>
            <hr>
        </div>
    </div>
    <div class="card" style="padding-left: 5%">
        <img class="card-img-top" src="img/creme3.jpg" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title">Creme Protetor Hidratante</h5>
            <h6 class="card-text">R$11,75</h6>
            <button class="btn btn-primary">Adicionar ao Carrinho</button>
        </div>
    </div>
    <br><br><br>
</div>


</body>
</html>