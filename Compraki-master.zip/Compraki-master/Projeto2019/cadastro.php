<html>
<head>
	<title>CompreAki</title>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="estilo.css">

    <style>
        * {
            box-sizing: border-box;
        }

        .row {
            display: -ms-flexbox; /* IE10 */
            display: flex;
            -ms-flex-wrap: wrap; /* IE10 */
            flex-wrap: wrap;
            margin: 0 -16px;
        }

        .col-25 {
            -ms-flex: 25%; /* IE10 */
            flex: 25%;
        }

        .col-50 {
            -ms-flex: 50%; /* IE10 */
            flex: 50%;
        }

        .col-75 {
            -ms-flex: 75%; /* IE10 */
            flex: 75%;
        }

        .col-25,
        .col-50,
        .col-75 {
            padding: 0 16px;
        }

        .container {
            padding: 5px 20px 15px 20px;
            border-radius: 3px;
        }

        input[type=text] {
            width: 100%;
            margin-bottom: 20px;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        label {
            margin-bottom: 10px;
            display: block;
        }

        .icon-container {
            margin-bottom: 20px;
            padding: 7px 0;
            font-size: 24px;
        }

        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 12px;
            margin: 10px 0;
            border: none;
            width: 100%;
            border-radius: 3px;
            cursor: pointer;
            font-size: 17px;
        }

        .btn:hover {
            background-color: #45a049;
        }

        a {
            color: #2196F3;
        }

        hr {
            border: 1px solid lightgrey;
        }

        span.price {
            float: right;
            color: grey;
        }

        /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
        @media (max-width: 800px) {
            .row {
                flex-direction: column-reverse;
            }
            .col-25 {
                margin-bottom: 20px;
            }
        }
        </style>
</head>

<body>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">CompreAki</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#sobre">SOBRE NÓS</a></li>
        <li><a href="#menu">MENU</a></li>
        <li><a href="#pricing"><div onclick="document.getElementById('id01').style.display='block'" style="width:auto;">LOGIN</div></a></li>

      </ul>
    </div>
  </div>
</nav>
<div class="jumbotron text-center laranja">
  <h1>Cadastrar-se</h1> 
  <p>Compre sem precisar sair de casa!</p> 
</div>





<div class="row">
  <div class="col-75">
    <div class="container" id="contaner">
      <form >
      
        <div class="row">
          <div class="col-75">
            <label for="fname"><i class="fa fa-user"></i> Nome completo</label>
            <input type="text" id="fname" name="firstname" placeholder="John M. Doe">

            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="john@example.com">

            <label for="senha1"><i class="fa fa-address-card-o"></i> Senha</label>
            <input type="password" id="adr" name="address" placeholder="Mínimo de 8 caracteres">

            <label for="senha2"><i class="fa fa-institution"></i> Confirmar senha</label>
            <input type="password" id="city" name="city" placeholder="Mínimo de 8 caracteres">

            <div class="row">
              <div class="col-50">
                <label for="state">Data de nascimento</label>
                <input type="date" id="state" name="state" placeholder="NY">
              </div>
              <div class="col-50">
                <label for="zip">Telefone</label>
                <input type="phone" id="zip" name="zip" placeholder="Ex: (99) 99999-9999">
              </div>
            </div>

            <div>
   <input type="submit" value="Enviar" class="btn">
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

</>
</html>